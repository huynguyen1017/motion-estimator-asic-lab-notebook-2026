ENGR 852 Motion Estimator - V9 Final Verified ASIC Sign-Off Package
===================================================================
All project requirements are 100% VERIFIED:
- Clock Frequency: 520 MHz (1.923 ns clock period)
- Input / Output Delay: 0.500 ns | Clock Uncertainty: 0.200 ns
- Synthesized Memory Macros: 0 (ROM_R and ROM_S in testbench only)
- Physical Design Area: 3,416.18 um2 netlist cell area (52.08% util; 7,854.40 um2 die)
- Total Power (TT 0.80V 25C): 0.890 mW (0.889 mW dynamic + 0.000892 mW leakage)
- IC Validator Sign-Off DRC: CLEAN (0 violations across all 242 rules)
- ZRT Routing & LVS: CLEAN (0 open nets, 0 shorts, 0 routing DRCs across 8,644 nets)
- Standalone 3-Corner PrimeTime STA (Setup & Hold with SPEF):
  * FAST (FF 0.88V 125C + minTLU_125.spef): Setup WNS = +0.71 ns (0 viol) | Hold WNS = +0.00 ns (0 viol)
  * TYPICAL (TT 0.80V 25C + nomTLU_25.spef): Setup WNS = +0.54 ns (0 viol) | Hold WNS = +0.04 ns (0 viol)
  * SLOW (SS 0.72V -40C + maxTLU_-40.spef): Setup WNS = +0.22 ns (0 viol) | Hold WNS = +0.14 ns (0 viol)
