ENGR 852 Motion Estimator - V4 package
======================================
Actual VCS/Verdi and Fusion Compiler mapped results are included.
Original source, corrected RTL, testbenches and SDC are editable.
The three additional slides are intended for independent contribution.

IMPORTANT PHYSICAL DESIGN GATES
Synthesis/floorplan/V3B placement: measured.
CTS / routing / DRC / parasitic extraction / post-layout PrimeTime setup & hold: NOT VERIFIED.
No final routed layout or extracted-timing values are fabricated.
Re-authentication to the authorized server is required to resume those stages.

Read the six-page report and docs/UPDATE-017_V4_FINAL_CHECKPOINT.md first.
Only source files and generated evidence are included. No licensed technology libraries.
